# Bandyövningar v0.1 – steg-editor

Första ombyggda MVP-versionen av den tidigare Bandy Animator-prototypen.

## Nytt i denna version
- Riktig SVG-ritad bandyplan med röda linjer.
- Målen ligger uppåt/nedåt på skärmen.
- Växla mellan **helplan** och **halvplan**.
- Växla mellan **anfall uppåt** och **anfall nedåt**.
- Objekt: spelare, orange kon, röd boll och text.
- Snabbval för MV och tränare.
- Etikett/text, färg och storlek på markerade objekt.
- Stegbaserad editor: Start → Steg 2 → Steg 3 osv.
- Rörelse skapas automatiskt av skillnaden mellan objektets position i två steg.
- Enkel passnings- och skottdefinition.
- Play, paus, starta om, hastighet och loop.
- Lokal Spara/Öppna i webbläsaren.
- Import/export som JSON.
- Mobilanpassat gränssnitt med touch-dragning.

## Arbetsflöde
1. Välj helplan eller halvplan.
2. Placera spelare, koner och boll i startläget.
3. Tryck **Lägg till steg**.
4. Flytta de objekt som ska ändras i nästa steg.
5. Lägg till passning/skott vid behov.
6. Fortsätt med fler steg och tryck Play.

## GitHub Pages
Ladda upp `index.html` till samma GitHub Pages-repo som tidigare. Ingen byggprocess eller externa bibliotek krävs.

## Begränsningar i v0.1
- Rörelsebanor är raka mellan steg. Fri kurvritning kommer senare.
- En passning/skott använder den första röda boll som finns i övningen.
- Spara/Öppna använder localStorage på den aktuella enheten/webbläsaren.
